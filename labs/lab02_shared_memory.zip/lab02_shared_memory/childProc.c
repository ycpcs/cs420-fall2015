#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <unistd.h>
#include "ipcEx.h"


int main(int argc, char** argv)
{
  char data_string[] = "Hello Shared Memory!\n";

  // TODO:
  // Insert your code here


  return 0;
}



